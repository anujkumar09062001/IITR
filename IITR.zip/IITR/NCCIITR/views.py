from django.shortcuts import render, redirect
from datetime import datetime
from NCCIITR.models import Contact
from django.contrib import messages
from .models import Destination, Cadet

# Create your views here.

def home(request):
    return render(request, 'home.html')


def team(request):

    #UO!!!

    dest1 = Destination()
    dest1.post = "UO"
    dest1.img = 'static/1.jfif'
    dest1.name = "Anuj Kumar"

    dest2 = Destination()
    dest2.post = "UO"
    dest2.img = 'static/2.jfif'
    dest2.name = "Ajay Thakur"

    dest3 = Destination()
    dest3.post = "Cadet"
    dest3.img = 'static/3.jpg'
    dest3.name = "Anil Rana"

    dests = [dest1, dest2, dest3]

    #Cadet!!!

    cadet1 = Cadet()
    cadet1.post = "UO"
    cadet1.img = 'static/1.jfif'
    cadet1.name = "Anuj"

    cadet2 = Cadet()
    cadet2.post = "UO"
    cadet2.img = 'static/2.jfif'
    cadet2.name = "Thakur"

    cadet3 = Cadet()
    cadet3.post = "Cadet"
    cadet3.img = 'static/3.jpg'
    cadet3.name = "Anil kumar Rana"

   
    cadets = [cadet1, cadet2, cadet3]

    return render(request, 'team.html', {'dests': dests , 'cadets': cadets})

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc, date=datetime.today())
        contact.save()
        messages.success(request, 'Your Details has been submitted!')
    return render(request, 'contact.html')
    #return HttpResponse("this is contact page")