from django.apps import AppConfig


class NcciitrConfig(AppConfig):
    name = 'NCCIITR'
