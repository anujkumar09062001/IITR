from django.contrib import admin
from django.urls import path
from NCCIITR import views

urlpatterns = [
    path('', views.home, name="home"),
    path("contact", views.contact, name='Contact'),
    path("team", views.team, name='team'),
]