from django.contrib import admin
from NCCIITR.models import Contact

# Register your models here.
admin.site.register(Contact)